import React from "react";
import MainPage from "./components/MainPage";
import { Button } from "antd";
import ReactDOM from 'react-dom';
import SignIn from "./components/SignIn";
import { BrowserRouter as Router } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import Navbar from "./components/Navbar";
import { ProductCard } from "./components/productCard";
import SignUp from "./components/SignUp";
import { BrowserRouter , Routes , Route} from 'react-router-dom';
import Dashboard from "./components/Dashboard";
import ProductLists from "./components/ProductTable";
import UserLists from "./components/UserTable";
import OrderLists from "./components/OrdersTable";
import { CRM } from "./components/CRM";
import { CustomerAssistance } from "./components/CustomerAssistance";
import { ECommerceSync } from "./components/ECommerceSync";
import EventsLists from "./components/Events"
import { Feedbacks } from "./components/Feedbacks";
import { Finance } from "./components/Finance";
import { LoyalityManagement } from "./components/LoyalityManagement";
import { Marketing } from "./components/Marketing";
import PartnersLists from "./components/Partners";
import { StaffDevelopment } from "./components/StaffDevelopment";
import SuppliersList from "./components/Suppliers";
import { Trends } from "./components/Trends";
import TeamsLists from "./components/Teams"
import { Mails } from "./components/Mails";
import Temp from "./components/Temp";
function App() {
  return (
    <div>
    
      <Routes>
      
      <Route exact path='/' element={<Dashboard />}>    </Route>
      <Route exact path='/signin' element={<SignIn />}>    </Route>
      <Route exact path='/signup' element={<SignUp />}>    </Route>
      <Route exact path='/admin/products' element={ <Dashboard LeftIfi={<ProductLists isSearchBox={true}/>}/>}>    </Route>
      <Route exact path='/admin/users' element={ <Dashboard LeftIfi={<UserLists isSearchBox={true}/>}/>}>    </Route>
      <Route exact path='/admin/orders' element={ <Dashboard LeftIfi={<OrderLists isSearchBox={true}/>}/>}>    </Route>
      <Route exact path='/admin/crm' element={ <Dashboard LeftIfi={<CRM />}/>}>    </Route>
      <Route exact path='/admin/temp' element={ <Dashboard LeftIfi={<Temp />}/>}>    </Route>
      <Route exact path='/admin/customer-assistance' element={ <Dashboard LeftIfi={<CustomerAssistance />}/>}> </Route>
      <Route exact path='/admin/e-commerce-sync' element={ <Dashboard LeftIfi={<ECommerceSync />}/>}>    </Route>
      <Route exact path='/admin/events' element={ <Dashboard LeftIfi={<EventsLists isSearchBox={true}/>}/>}>    </Route>
      <Route exact path='/admin/feedbacks' element={ <Dashboard LeftIfi={<Feedbacks />}/>}>    </Route>
      <Route exact path='/admin/finance' element={ <Dashboard LeftIfi={<Finance />}/>}>    </Route>
      <Route exact path='/admin/loyality-management' element={ <Dashboard LeftIfi={<LoyalityManagement />}/>}>    </Route>
      <Route exact path='/admin/marketing' element={ <Dashboard LeftIfi={<Marketing />}/>}>    </Route>
      <Route exact path='/admin/partners' element={ <Dashboard LeftIfi={<PartnersLists isSearchBox={true}/>}/>}>    </Route>
      <Route exact path='/admin/staff-development' element={ <Dashboard LeftIfi={<StaffDevelopment />}/>}>    </Route>
      <Route exact path='/admin/suppliers' element={ <Dashboard LeftIfi={<SuppliersList isSearchBox={true}/>}/>}>    </Route>
      <Route exact path='/admin/trends' element={ <Dashboard LeftIfi={<Trends />}/>}>    </Route>
      <Route exact path='/admin/teams' element={ <Dashboard LeftIfi={<TeamsLists isSearchBox={true}/>}/>}>    </Route>
      <Route exact path='/admin/mail/all-mails' element={ <Dashboard LeftIfi={<Mails isSearchBox={true}/>}/>}>    </Route>
      <Route exact path='/admin/mail/trash' element={ <Dashboard LeftIfi={<Mails />}/>}>    </Route>
      <Route exact path='/admin/mail/spam' element={ <Dashboard LeftIfi={<Mails />}/>}>    </Route>
      </Routes>
    
    </div>
  );
}

export default App;
