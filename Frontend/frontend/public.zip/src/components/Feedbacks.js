import React, { startTransition } from 'react'
import { Link } from 'react-router-dom'
import { Rating } from 'react-simple-star-rating'


export const Feedbacks = (props) => {
    return (
        <div>
            Feedbacks
        </div>
    );
}
