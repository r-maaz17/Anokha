import * as React from 'react';
import PropTypes from 'prop-types';
import Box from '@mui/material/Box';
import Collapse from '@mui/material/Collapse';
import IconButton from '@mui/material/IconButton';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import { styled } from '@mui/material/styles';
import { tableCellClasses } from '@mui/material/TableCell';

function createData(name, ...values) {
    const row = { name, history: [] };
    values.forEach((value, index) => {
        row[`col_${index + 1}`] = value.toString();
    });
    console.log("Rows", row)
    return row;
}
const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    },
}));
const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));

function Row(props) {
    const { row } = props;
    const [open, setOpen] = React.useState(false);
    const tableHeaders = Object.keys(row.data);

    return (
        <React.Fragment>
            <TableRow sx={{ '& > *': { borderBottom: 'unset' } }}>
                <TableCell>
                    <IconButton
                        aria-label="expand row"
                        size="small"
                        onClick={() => setOpen(!open)}
                    >
                        {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
                    </IconButton>
                </TableCell>
                {Object.entries(row.data).map(([key, value]) => (
                    <TableCell align="center">
                        {value}
                    </TableCell>
                ))}
            </TableRow>
            <TableRow>
                <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={Object.keys(row).length}>
                    <Collapse in={open} timeout="auto" unmountOnExit>
                        <Box sx={{ margin: 1 }}>
                            <Typography variant="h6" gutterBottom component="div">
                                History
                            </Typography>
                            <Table size="small" aria-label="purchases">
                                <TableHead>
                                    <TableRow>
                                        {
                                            Object.keys(row.other[0]).map((key)=>(
                                                
                                                <TableCell>{key}</TableCell>
                                            ))
                                        }
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {row.other.map((data) => (
                                        <TableRow>
                                             {Object.entries(data).map(([key, value]) => (
                                                <TableCell>{value}</TableCell>
                                             ))}
                                            
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </Box>
                    </Collapse>
                </TableCell>
            </TableRow>
        </React.Fragment>
    );
}
//Example Data
// const rows = {
//     actions: [
//         {
//             'name': 'Edit',
//             'enable': 'true',
//             'action': ''
//         },
//         {
//             'name': 'Delete',
//             'enable': 'true',
//             'action': ''
//         }
//     ],
//     data: [{
//         data: {
//             'name': 'asd',
//             'roll': '123',
//             'id': '123',
//             'location': 'lahore',
//         },
//         other: [{
//             'date': '231',
//             'price': '123213',
//             'uploadedDate': '2312'
//         }]
//     }
//     ]
// };


export default function ExtendedTable(props) {
    const rows = props.rows;
    const tableHeaders = rows.data && rows.data.length > 0 ? Object.keys(rows.data[0].data) : [];
    console.log("Table Headers", tableHeaders)
    return (
        <TableContainer component={Paper}>
            <Table aria-label="collapsible table">
                <TableHead>
                    <StyledTableRow>
                        <StyledTableCell />
                        {tableHeaders.map((header) => (
                            <StyledTableCell key={header} align="center">{header}</StyledTableCell>
                        )
                        )}
                        {rows.actions.map((action) => (
                            action.enable === 'true' ? <StyledTableCell align="center" key={action.name}>{action.name}</StyledTableCell> : <></>
                        ))}

                    </StyledTableRow>

                </TableHead>
                <TableBody>
                    {rows.data.map((row) => (
                        <Row key={row.id} row={row} />
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
}
