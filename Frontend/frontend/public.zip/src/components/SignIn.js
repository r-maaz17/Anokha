import React from 'react';
import { useState } from 'react';
import { API_URLS } from './apis/apiConfig';
import axios from 'axios';
import {
    MDBContainer,
    MDBInput,
    MDBCheckbox,
    MDBBtn,
    MDBIcon
}


    from 'mdb-react-ui-kit';
import Navbar from './Navbar';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
const SignIn = () => {
    const [error,setError] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();
    const handleLogin = async () => {
        // try {
            console.log(email,password,"user")
          const response = await axios.post(API_URLS.SIGN_IN, {
            email: email,
            password: password,
          });
    
          // Log the JSON response
          console.log('Response:', response.data);
          if (response.status == 200){
                navigate('/home')
          }
          else{
            setError("Error");
          }
          // Save the token in localStorage with a 24-hour expiration
          const expirationTime = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
          const expirationDate = new Date().getTime() + expirationTime;
          localStorage.setItem('JWT-Token', response.data.token);
          localStorage.setItem('Expiration', expirationDate);
    
        // } catch (error) {
        //     setError('Error in catch')
        //   console.error('Error:', error.response.data);
        // }
      };
    return (
        <div>
            <Navbar />
            <MDBContainer className="p-3 my-5 d-flex flex-column w-50">
                {error}
                <MDBInput wrapperClass='mb-4' label='Email address' id='form1' type='email' onChange={(e) => setEmail(e.target.value)} />
                <MDBInput wrapperClass='mb-4' label='Password' id='form2' type='password' onChange={(e) => setPassword(e.target.value)} />

                <Button className="mb-4" variant="contained" color="primary" onClick={handleLogin}>Sign in</Button>

                <div className="text-center">
                    <p>Not a member? <a href="#!">Register</a></p>
                </div>

            </MDBContainer>
        </div>
    );
}

export default SignIn;