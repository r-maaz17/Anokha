import * as React from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Button } from '@mui/material';
import { Modal, Form, Input, Select } from 'antd';
import { useState } from 'react';
import axios from 'axios';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));

function createData(name, calories, fat, carbs, protein) {
    return { name, calories, fat, carbs, protein };
}

const rows = [
    createData('Frozen yoghurt', 159, 6.0, 24, 4.0),
    createData('Ice cream sandwich', 237, 9.0, 37, 4.3),
    createData('Eclair', 262, 16.0, 24, 6.0),
    createData('Cupcake', 305, 3.7, 67, 4.3),
    createData('Gingerbread', 356, 16.0, 49, 3.9),
];
const { Option } = Select;
const layout = {
    labelCol: {
        span: 8,
    },
    wrapperCol: {
        span: 16,
    },
};
const tailLayout = {
    wrapperCol: {
        offset: 8,
        span: 16,
    },
};

export default function OrderLists(props) {
    const [formData, setFormData] = useState({});
    const [editOrder ,setEditOrder] = useState({})
    const [loading,setLoading] = useState(false);
    
    React.useEffect(() =>{
        getOrders();
    },[])
    const getOrders = async () => {
        try {

            const {data} = await axios.get('http://localhost:8000/api/v1/orders');
            console.log(data);
            setOrders(data)
        }
        catch {
            console.log("Error in fething Orders")
        }
    }
    const [Orders,setOrders] = useState([])
    const formRef = React.useRef(null);
    const [isEdit, setIsEdit] = useState(false);
    const Reject = (id) => {
        
       //
        


    }
    const getOrder = async (id)=>{
        try {
            setLoading(true);
            const {data} = await axios.get(`http://localhost:8000/api/v1/orders/${id}`);
            console.log('data',data)
            setEditOrder(data)
            console.log('a',editOrder)
            setLoading(false);
          } catch (error) {
          }
    }
    const editData = async () => {
        try {
          const {data} = await axios.put(`http://localhost:8000/api/v1/orders/${editOrder?._id}`, formData );
          getOrders()
    
        } catch (error) {}
      }
      const Approve = async (id) => {
        try {
          const data = await axios.delete(`http://localhost:8000/api/v1/orders/${id}`);
          getOrders();
        } catch (error) {}
      };
      const addOrder = async () => {
        try {
            const {data} = await axios.post(`http://localhost:8000/api/v1/orders`, formData );
            getOrders()
      
          } catch (error) {}
      }
    const onGenderChange = (value) => {
        switch (value) {
            case 'male':
                formRef.current?.setFieldsValue({
                    note: 'Hi, man!',
                });
                break;
            case 'female':
                formRef.current?.setFieldsValue({
                    note: 'Hi, lady!',
                });
                break;
            case 'other':
                formRef.current?.setFieldsValue({
                    note: 'Hi there!',
                });
                break;
            default:
                break;
        }
    };
    const onFinish = (values) => {
        console.log(values);
        setIsEdit(false)
        editData();
    };
    const onReset = () => {
        formRef.current?.resetFields();
    };
    const onFill = () => {
        formRef.current?.setFieldsValue({
            note: 'Hello world!',
            gender: 'male',
        });
    };
    const [isModalOpen, setIsModalOpen] = useState(false);
    const showModal = () => {
        setIsModalOpen(true);
    };
    const handleOk = () => {
        setIsModalOpen(false);
        setIsEdit(false)
        if (isEdit){
        
        editData();}
        else if(!isEdit){
            addOrder();
        }
    };
    const handleCancel = () => {
        setIsModalOpen(false);
        setIsEdit(false)
    };
    async function submit(e) {
        e.preventDefault();
    
        // console.log(formData.category);
        try {
          setLoading(true);
          const {data} = await axios.post("http://localhost:8000/api/v1/orders",formData);
    
          setOrders([...Orders, data])
          setLoading(false);
          onFinish();
    
          // console.log("SIGNUP RESPONSE: ", data);
        } catch (err) {
          setLoading(false);
        }
      }
    return (

        <div>

                
            <Button style={{ marginLeft: 950, marginBottom: 20 }} variant="contained" color="primary" onClick={showModal}>
                Add
            </Button>
            <TableContainer component={Paper}>
                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                    <TableHead>
                        <TableRow>
                            
                            <StyledTableCell align="center">Order Name</StyledTableCell>
                            <StyledTableCell align="center">Customer Email</StyledTableCell>
                            <StyledTableCell align="center">Order Date</StyledTableCell>
                            <StyledTableCell align="center">Status</StyledTableCell>
                            <StyledTableCell align="center">Reject</StyledTableCell>
                            <StyledTableCell align="center">Approve</StyledTableCell>

                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {[].map((row) => (
                            <StyledTableRow key={row.name}>
                                {/* <StyledTableCell component="th" scope="row">
                                    {row.name}
                                </StyledTableCell> */}
                                <StyledTableCell align="center">{row.OrderName}</StyledTableCell>
                                <StyledTableCell align="center">{row.CustomerEmail}</StyledTableCell>
                                <StyledTableCell align="center">{row.OrderDate}</StyledTableCell>
                                <StyledTableCell align="center">{row.Status}</StyledTableCell>
                                <StyledTableCell align="center"><Button onClick={()=>Reject(row._id)} variant="contained" color="success">Edit</Button></StyledTableCell>
                                <StyledTableCell align="center"><Button onClick={()=>Approve(row._id)} variant="contained" color="error">Delete</Button></StyledTableCell>


                            </StyledTableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </div>
    );
}