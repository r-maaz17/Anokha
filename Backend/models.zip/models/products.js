const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  ProductName: String,
  Description: String,
  Price: String,
  StockQuantity: String,
  LowStockThreshold: String,
  image:String,
});

module.exports = mongoose.model('Product', productSchema);
